# Network-Programming-C-

Bài 1 HTTP Server sử dụng preforking 
Ảnh chạy chương trình bài 1
![image](https://github.com/vanhao2310/Network-Programming-C-/assets/89892191/09998f3d-f20b-46da-8fec-dee9c6349a4b)

Bài 2 time_server
Ảnh chạy chương trình bài 2
![image](https://github.com/vanhao2310/Network-Programming-C-/assets/89892191/3d9a2996-d251-40a9-9ad6-4c78ce30b5b1)

